
for running the naive bayes with excluding the stop words
$  python naiveBayesWithStopWordsExcluded.py

for running the naive bayes including the stop words
$  python naiveBayes.py

for running the naive bayes on training dataset
$  python naiveBayesForTraining.py